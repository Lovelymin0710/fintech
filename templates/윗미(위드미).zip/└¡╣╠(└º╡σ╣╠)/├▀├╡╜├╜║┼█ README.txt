*추천시스템 readme

1.visual studio 설치한다
2.terminal 을 킨다
3. pip install pandas 
4. pip install tqdm 
5. pd.read_csv(경로)